from rest_framework.viewsets import ModelViewSet
from .models import Customer, Product
from .serializers import SignUpSerializer, ProductSerializer

class CustomerViewSet(ModelViewSet):
    queryset = Customer.objects.all()
    serializer_class = SignUpSerializer

class ProductViewSet(ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer