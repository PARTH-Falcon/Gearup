from rest_framework import serializers
from .models import Customer, Product

class SignUpSerializer(serializers.ModelSerializer):
    class Meta:
        model = Customer
        fields = ['username','email','password']

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ['id','name','description','price_per_day','stock']